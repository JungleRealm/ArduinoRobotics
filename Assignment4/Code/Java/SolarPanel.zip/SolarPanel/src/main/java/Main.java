import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.time.Second;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.time.TimeSeries;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.swing.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

public class Main {
    private static TimeSeries seriesMLX = new TimeSeries("Infrared Sensor (MLX90614)");
    private static TimeSeries seriesLM35 = new TimeSeries("LM35 Sensor");

    private static final String DB_URL = "jdbc:postgresql://localhost:5432/solar";
    private static final String DB_USER = "postgres";
    private static final String DB_PASSWORD = "DATABASE_PASSWORD";

    public static void main(String[] args) throws Exception {

        // Setup graph
        JFrame frame = new JFrame("Temperature Monitor");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // 600 sec
        seriesMLX.setMaximumItemCount(600);
        seriesLM35.setMaximumItemCount(600);
        TimeSeriesCollection dataset = new TimeSeriesCollection();
        dataset.addSeries(seriesMLX);
        dataset.addSeries(seriesLM35);

        JFreeChart chart = ChartFactory.createTimeSeriesChart(
                "Live Temperature Data",
                "Time",
                "°C",
                dataset,
                true,
                true,
                false
        );

        frame.add(new ChartPanel(chart));
        frame.setSize(800, 600);
        frame.setVisible(true);

        // Setup server
        int port = 5000;
        ServerSocket server = new ServerSocket(port);
        System.out.println("Server running. Waiting for NodeMCU...");

        Socket client = server.accept();
        System.out.println("NodeMCU connected!");

        BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));

        // Read data
        String line;
        while ((line = in.readLine()) != null) {
            try {
                // Expected format: MLX=23.5;LM35=24.1
                String[] parts = line.split(";");
                double mlx = Double.parseDouble(parts[0].split("=")[1]);
                double lm35 = Double.parseDouble(parts[1].split("=")[1]);
                boolean badValue = (mlx <= -20 || lm35 <= -20 || mlx >= 60 || lm35 >= 60);

                if (badValue) {
                    mlx = Double.NaN;
                    lm35 = Double.NaN;
                }

                System.out.println("MLX90614 = " + mlx + " °C,   LM35 = " + lm35 + " °C");
                seriesMLX.addOrUpdate(new Second(), mlx);
                seriesLM35.addOrUpdate(new Second(), lm35);
                insertTemperature(mlx, lm35);
            } catch (Exception e) {
                System.out.println("Invalid data: " + line);
            }
        }
    }

    private static void insertTemperature(Double mlx, Double lm35) {
        String sql = "INSERT INTO temperature (mlx_temp, lm35_temp) VALUES (?, ?)";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement databaseData = conn.prepareStatement(sql)) {

            if (mlx.isNaN()) databaseData.setNull(1, java.sql.Types.DOUBLE);
            else databaseData.setDouble(1, mlx);

            if (lm35.isNaN()) databaseData.setNull(2, java.sql.Types.DOUBLE);
            else databaseData.setDouble(2, lm35);

            databaseData.executeUpdate();
        } catch (Exception e) {
            System.out.println("Database error: " + e.getMessage());
        }
    }
}
