import com.fazecast.jSerialComm.SerialPort;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.*;
import java.util.Scanner;

public class Main {
    private static final String URL = "jdbc:postgresql://localhost:5432/criminals";
    private static final String USER = "postgres";

    public static void main(String[] args) {
        SerialPort comPort = SerialPort.getCommPort("COM4");
        comPort.setBaudRate(9600);
        comPort.setComPortTimeouts(SerialPort.TIMEOUT_READ_BLOCKING, 2000, 0);

        if (!comPort.openPort()) {
            System.err.println("Failed to open serial port.");
            return;
        }

        System.out.println("Serial port opened. Waiting for Arduino...");

        try { Thread.sleep(2000); } catch (InterruptedException ignored) {}

        System.out.print("Input password for your database: ");
        Scanner scanner = new Scanner(System.in);
        String PASSWORD = scanner.nextLine();
        scanner.close();

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            System.out.println("Connected to PostgreSQL database.");

            BufferedReader reader = new BufferedReader(new InputStreamReader(comPort.getInputStream()));

            while (true) {
                String line = null;
                try {
                    line = reader.readLine();
                } catch (com.fazecast.jSerialComm.SerialPortTimeoutException e) {
                    //continue waiting
                    continue;
                }
                if (line == null || line.isBlank()) continue;

                try {
                    // Skip startup messages (like “Servo control ready!”)
                    if (!line.contains("Speed:")) {
                        System.out.println("Skipping unrelated message: " + line);
                        continue;
                    }

                    // Example format: "Delta time = 174 ms | Speed: 0.00012 cm/ms | 0.012 m/s | 0.043 km/h"
                    String[] parts = line.split("\\|");

                    // Extract and clean up values
                    String deltaPart = parts[0].replace("Delta time =", "").replace("ms", "").trim();
                    String speedCmMs = parts[1].replace("Speed:", "").replace("cm/ms", "").trim();
                    String speedMs = parts[2].replace("m/s", "").trim();
                    String speedKmh = parts[3].replace("km/h", "").trim();

                    // Write a message to console
                    System.out.println("Parsed -> delta t: " + deltaPart + " ms, cm/ms: " + speedCmMs + ", m/s: " + speedMs + ", km/h: " + speedKmh);

                    // Insert into database
                    String sql = "INSERT INTO fines (time, speedcmms, speedms, speedkmh) VALUES (NOW(), ?, ?, ?)";
                    try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                        stmt.setString(1, speedCmMs);
                        stmt.setString(2, speedMs);
                        stmt.setString(3, speedKmh);
                        stmt.executeUpdate();
                        System.out.println("Inserted into database.");
                    }
                } catch (Exception e) {
                    System.err.println("Failed to parse line: " + line);
                    e.printStackTrace();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            comPort.closePort();
            System.out.println("Serial port closed.");
        }
    }
}
