import com.fazecast.jSerialComm.SerialPort;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.regex.Pattern;

public class Main {

    // Data needed to connect to the database
    private static final String URL = "jdbc:postgresql://localhost:5432/arduino";
    private static final String USER = "postgres";

    // Regex patterns for Serial data validation later in the code
    private static final Pattern TIME_PATTERN = Pattern.compile("\\d{2}:\\d{2}:\\d{2}");
    private static final Pattern TEMP_PATTERN = Pattern.compile("-?\\d+(\\.\\d+)? [CF]");
    private static final Pattern MODE_PATTERN = Pattern.compile("Celcius|Fahrenheit");
    private static final Pattern CALIB_PATTERN = Pattern.compile("-?\\d+(\\.\\d+)? C");

    public static void main(String[] args) {
        SerialPort comPort = SerialPort.getCommPort("COM4");
        comPort.setBaudRate(9600);

        // Set a 2 second timeout. We read values sent over Serial every 2 secondsVyteniukas9

        comPort.setComPortTimeouts(SerialPort.TIMEOUT_READ_BLOCKING, 2000, 0);

        // If Arduino is not connected to Serial port COM4 break the program
        if (!comPort.openPort()) {
            System.err.println("Failed to open serial port.");
            return;
        }
        System.out.println("Serial port opened. Waiting for Arduino...");

        // Set a 2 second timeout before starting to read values. This is needed to give arduino enough time to set up
        try { Thread.sleep(2000); } catch (InterruptedException ignored) {}

        // Ask the user for a database password
        System.out.println("Input Password for your database:");
        Scanner scanner = new Scanner(System.in);
        String PASSWORD = scanner.nextLine();
        scanner.close();

        // Connect to the database
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            System.out.println("Connected to PostgreSQL database.");


            // Start the loop of reading and parsing values
            BufferedReader reader = new BufferedReader(new InputStreamReader(comPort.getInputStream()));
            String line;

            while ((line = reader.readLine()) != null) {
                try {
                    String[] parts = line.split("\\|");

                    String timestamp = line.substring(0, line.indexOf("Temp:")).trim();
                    String temperature = parts[0].split("Temp:")[1].trim();
                    String mode = parts[1].split("Mode:")[1].trim();
                    String calibration = parts[2].split("Offset:")[1].trim();

                    // Validate each part using regex defined in code lines 17-21
                    if (!TIME_PATTERN.matcher(timestamp).matches() ||
                            !TEMP_PATTERN.matcher(temperature).matches() ||
                            !MODE_PATTERN.matcher(mode).matches() ||
                            !CALIB_PATTERN.matcher(calibration).matches()) {
                        System.err.println("Invalid message format, skipping: " + line);
                        // if at least one of the parameters is wrong, skip over the remaining loop iteration
                        continue;
                    }

                    System.out.println("Parsed -> time: " + timestamp +
                            ", temp: " + temperature +
                            ", mode: " + mode +
                            ", calib: " + calibration);

                    // Insert data into the database
                    String sql = "INSERT INTO temp (time, temperature, mode, calibration) VALUES (?, ?, ?, ?)";
                    try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                        stmt.setString(1, timestamp);
                        stmt.setString(2, temperature);
                        stmt.setString(3, mode);
                        stmt.setString(4, calibration);
                        stmt.executeUpdate();
                        System.out.println("Inserted into database.");
                    }
                } catch (Exception e) {
                    System.err.println("Failed to parse line: " + line);
                    e.printStackTrace();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            comPort.closePort();
            System.out.println("Serial port closed.");
        }
    }
}
